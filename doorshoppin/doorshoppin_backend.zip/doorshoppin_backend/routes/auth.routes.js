import express from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { getDatabase, query } from "../config/database.js";
import { v4 as uuidv4 } from "uuid";

const router = express.Router();

/* ----------------------------------------
   HEALTH CHECK
----------------------------------------- */
router.get("/health", (req, res) => {
  res.setHeader('Content-Type', 'application/json');
  res.status(200).json({
    status: "OK",
    message: "Doorshoppin Auth service is running",
    timestamp: new Date().toISOString()
  });
});

/* ----------------------------------------
   REGISTER USER (supports email or phone)
----------------------------------------- */
router.post("/register", async (req, res) => {
  res.setHeader('Content-Type', 'application/json');
  
  try {
    const { name, email, phone, password } = req.body;

    // Validate - must have either email or phone
    if (!name || !password) {
      return res.status(400).json({ error: "Name and password are required" });
    }

    if (!email && !phone) {
      return res.status(400).json({ error: "Either email or phone number is required" });
    }

    if (password.length < 6) {
      return res.status(400).json({ error: "Password must be at least 6 characters" });
    }

    // Validate email if provided
    if (email) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email)) {
        return res.status(400).json({ error: "Invalid email format" });
      }
    }

    // Validate phone if provided
    if (phone && phone.length < 8) {
      return res.status(400).json({ error: "Invalid phone number format" });
    }

    // Check existing user (email or phone must be unique)
    let checkSql = "";
    let checkParams = [];

    if (email && phone) {
      checkSql = "SELECT id FROM users WHERE email = ? OR phone = ?";
      checkParams = [email.toLowerCase(), phone];
    } else if (email) {
      checkSql = "SELECT id FROM users WHERE email = ?";
      checkParams = [email.toLowerCase()];
    } else {
      checkSql = "SELECT id FROM users WHERE phone = ?";
      checkParams = [phone];
    }

    const existingUsers = await query(checkSql, checkParams);
    
    if (existingUsers.length > 0) {
      return res.status(400).json({ error: "User with this email or phone already exists" });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Generate firebase_uid (required field, but we can use a UUID for non-firebase users)
    const firebaseUid = uuidv4();

    // Create new user
    const insertSql = `
      INSERT INTO users (firebase_uid, name, email, password, phone, created_at)
      VALUES (?, ?, ?, ?, ?, NOW())
    `;

    const result = await query(insertSql, [
      firebaseUid,
      name,
      email ? email.toLowerCase() : null,
      hashedPassword,
      phone || null,
    ]);

    const userId = result.insertId;

    // Generate token
    const token = jwt.sign(
      {
        userId: userId.toString(),
        email: email ? email.toLowerCase() : null,
      },
      process.env.JWT_SECRET || "default-secret-change-me",
      { expiresIn: "7d" }
    );

    return res.status(201).json({
      message: "User registered successfully",
      token,
      user: {
        id: userId,
        name: name,
        email: email ? email.toLowerCase() : null,
        phone: phone || null,
      },
    });
  } catch (err) {
    console.error("❌ Registration Error:", err);
    return res.status(500).json({
      error: "Internal server error",
      message: err.message || "An unexpected error occurred",
    });
  }
});

/* ----------------------------------------
   LOGIN USER (supports email or phone)
----------------------------------------- */
router.post("/login", async (req, res) => {
  res.setHeader('Content-Type', 'application/json');
  
  try {
    const { email, phone, password } = req.body;

    // Validate - must have either email or phone
    if (!password) {
      return res.status(400).json({ error: "Password is required" });
    }

    if (!email && !phone) {
      return res.status(400).json({ error: "Either email or phone number is required" });
    }

    // Find user by email or phone
    let sql = "";
    let params = [];

    if (email) {
      sql = "SELECT id, name, email, password, phone FROM users WHERE email = ?";
      params = [email.toLowerCase()];
    } else {
      sql = "SELECT id, name, email, password, phone FROM users WHERE phone = ?";
      params = [phone];
    }

    const users = await query(sql, params);

    if (users.length === 0) {
      return res.status(401).json({ error: "Invalid credentials" });
    }

    const user = users[0];

    // Password check
    const match = await bcrypt.compare(password, user.password);
    if (!match) {
      return res.status(401).json({ error: "Invalid credentials" });
    }

    // Update last_login
    await query("UPDATE users SET last_login = NOW() WHERE id = ?", [user.id]);

    // Get user ID
    const userId = user.id.toString();

    // Generate token
    const token = jwt.sign(
      {
        userId: userId,
        email: user.email,
      },
      process.env.JWT_SECRET || "default-secret-change-me",
      { expiresIn: "7d" }
    );

    return res.json({
      message: "Login successful",
      token,
      user: {
        id: userId,
        name: user.name,
        email: user.email,
        phone: user.phone,
      },
    });
  } catch (err) {
    console.error("❌ Login Error:", err);
    return res.status(500).json({
      error: "Internal server error",
      message: err.message,
    });
  }
});

export default router;
