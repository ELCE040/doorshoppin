import express from "express";
import { getDatabase, query } from "../config/database.js";
import { authenticate } from "../middleware/auth.middleware.js";
import { v4 as uuidv4 } from "uuid";

const router = express.Router();

/* ----------------------------------------
   CREATE ORDER
---------------------------------------- */
router.post("/", async (req, res) => {
  try {
    const {
      userId,
      items, // Array of { productId, name, price, quantity }
      deliveryInfo, // { name, phone, email, address, placeDescription, location }
      paymentMethod, // 'cash' or 'mobile'
      subtotal,
      deliveryFee,
      total,
    } = req.body;

    // Validate required fields
    if (!items || !Array.isArray(items) || items.length === 0) {
      return res.status(400).json({
        success: false,
        error: "Order must contain at least one item",
      });
    }

    if (!deliveryInfo || !deliveryInfo.name || !deliveryInfo.phone || !deliveryInfo.address) {
      return res.status(400).json({
        success: false,
        error: "Delivery information is required (name, phone, address)",
      });
    }

    if (!paymentMethod) {
      return res.status(400).json({
        success: false,
        error: "Payment method is required",
      });
    }

    // Generate order tracking ID
    const orderTrackingId = `DS-${new Date().getFullYear()}-${String(Math.floor(Math.random() * 10000)).padStart(4, "0")}`;

    // Insert order
    const orderSql = `
      INSERT INTO orders (user_id, status, total_amount, latitude, longitude, address, order_tracking_id, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
    `;

    const latitude = deliveryInfo.location?.lat || null;
    const longitude = deliveryInfo.location?.lng || null;
    const totalAmount = parseFloat(total) || 0;

    const result = await query(orderSql, [
      userId || null,
      "pending",
      totalAmount,
      latitude,
      longitude,
      deliveryInfo.address,
      orderTrackingId,
    ]);

    const orderId = result.insertId;

    // Insert order items into transactions table (or create order_items table if needed)
    // For now, we'll store items as JSON in a note or create transactions
    // You may want to create an order_items table later
    for (const item of items) {
      const transactionSql = `
        INSERT INTO transactions (transaction_id, user_id, user_email, amount, method, status, product_id, product_name, quantity, unit_price, created_at)
        VALUES (?, ?, ?, ?, ?, 'pending', ?, ?, ?, ?, NOW())
      `;
      
      await query(transactionSql, [
        orderTrackingId,
        userId || null,
        deliveryInfo.email || null,
        parseFloat(item.price) * item.quantity,
        paymentMethod,
        item.productId,
        item.name,
        item.quantity,
        parseFloat(item.price),
      ]);
    }

    // If user has temp_orders, clear them (optional - for logged-in users)
    if (userId) {
      await query("DELETE FROM temp_orders WHERE user_id = ?", [userId]);
    }

    res.status(201).json({
      success: true,
      message: "Order created successfully",
      data: {
        orderId: orderId,
        orderTrackingId: orderTrackingId,
        total: totalAmount,
        status: "pending",
      },
    });
  } catch (error) {
    console.error("Error creating order:", error);
    res.status(500).json({
      success: false,
      error: "Failed to create order",
      message: error.message,
    });
  }
});

/* ----------------------------------------
   GET USER ORDERS (authenticated)
---------------------------------------- */
router.get("/my-orders", authenticate, async (req, res) => {
  try {
    const userId = req.userId; // From auth middleware
    const { limit = 20, skip = 0 } = req.query;

    const sql = `
      SELECT id, user_id as userId, status, total_amount as totalAmount, 
             latitude, longitude, address, order_tracking_id as orderTrackingId,
             created_at as createdAt, updated_at as updatedAt
      FROM orders
      WHERE user_id = ?
      ORDER BY created_at DESC
      LIMIT ? OFFSET ?
    `;

    const orders = await query(sql, [userId, parseInt(limit), parseInt(skip)]);

    // Get total count
    const [countResult] = await query(
      "SELECT COUNT(*) as total FROM orders WHERE user_id = ?",
      [userId]
    );
    const total = countResult.total;

    res.json({
      success: true,
      data: orders,
      pagination: {
        total,
        limit: parseInt(limit),
        skip: parseInt(skip),
        hasMore: parseInt(skip) + orders.length < total,
      },
    });
  } catch (error) {
    console.error("Error fetching orders:", error);
    res.status(500).json({
      success: false,
      error: "Failed to fetch orders",
      message: error.message,
    });
  }
});

/* ----------------------------------------
   GET ORDER BY ID
---------------------------------------- */
router.get("/:id", async (req, res) => {
  try {
    const { id } = req.params;

    // Try to find by ID first, then by order_tracking_id
    let sql = `
      SELECT id, user_id as userId, status, total_amount as totalAmount,
             latitude, longitude, address, order_tracking_id as orderTrackingId,
             created_at as createdAt, updated_at as updatedAt
      FROM orders
      WHERE id = ?
    `;

    let orders = await query(sql, [id]);

    // If not found by ID, try order_tracking_id
    if (orders.length === 0) {
      sql = `
        SELECT id, user_id as userId, status, total_amount as totalAmount,
               latitude, longitude, address, order_tracking_id as orderTrackingId,
               created_at as createdAt, updated_at as updatedAt
        FROM orders
        WHERE order_tracking_id = ?
      `;
      orders = await query(sql, [id]);
    }

    if (orders.length === 0) {
      return res.status(404).json({
        success: false,
        error: "Order not found",
      });
    }

    const order = orders[0];

    // If authenticated, verify user owns the order (unless admin)
    if (req.userId && order.userId && order.userId.toString() !== req.userId) {
      return res.status(403).json({
        success: false,
        error: "Access denied",
      });
    }

    res.json({
      success: true,
      data: order,
    });
  } catch (error) {
    console.error("Error fetching order:", error);
    res.status(500).json({
      success: false,
      error: "Failed to fetch order",
      message: error.message,
    });
  }
});

/* ----------------------------------------
   TRACK ORDER BY ORDER ID
---------------------------------------- */
router.get("/track/:orderId", async (req, res) => {
  try {
    const { orderId } = req.params;

    const sql = `
      SELECT id, user_id as userId, status, total_amount as totalAmount,
             latitude, longitude, address, order_tracking_id as orderTrackingId,
             created_at as createdAt, updated_at as updatedAt
      FROM orders
      WHERE order_tracking_id = ?
    `;

    const orders = await query(sql, [orderId]);

    if (orders.length === 0) {
      return res.status(404).json({
        success: false,
        error: "Order not found",
      });
    }

    const order = orders[0];

    // Return order with status timeline
    const statusTimeline = [
      { label: "Pending", completed: order.status !== "pending" },
      { label: "Processing", completed: ["processing", "out_for_delivery", "delivered"].includes(order.status) },
      { label: "Out for delivery", completed: ["out_for_delivery", "delivered"].includes(order.status) },
      { label: "Delivered", completed: order.status === "delivered" },
    ];

    res.json({
      success: true,
      data: {
        orderId: order.id,
        orderTrackingId: order.orderTrackingId,
        status: order.status,
        statusTimeline,
        total: parseFloat(order.totalAmount),
        deliveryInfo: {
          address: order.address,
          latitude: order.latitude,
          longitude: order.longitude,
        },
        createdAt: order.createdAt,
        updatedAt: order.updatedAt,
      },
    });
  } catch (error) {
    console.error("Error tracking order:", error);
    res.status(500).json({
      success: false,
      error: "Failed to track order",
      message: error.message,
    });
  }
});

/* ----------------------------------------
   UPDATE ORDER STATUS
---------------------------------------- */
router.patch("/:id/status", async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    const validStatuses = ["pending", "processing", "out_for_delivery", "delivered", "cancelled"];
    if (!status || !validStatuses.includes(status)) {
      return res.status(400).json({
        success: false,
        error: `Status must be one of: ${validStatuses.join(", ")}`,
      });
    }

    // Find order by ID or order_tracking_id
    let findSql = "SELECT id FROM orders WHERE id = ?";
    let orders = await query(findSql, [id]);

    if (orders.length === 0) {
      findSql = "SELECT id FROM orders WHERE order_tracking_id = ?";
      orders = await query(findSql, [id]);
    }

    if (orders.length === 0) {
      return res.status(404).json({
        success: false,
        error: "Order not found",
      });
    }

    const orderId = orders[0].id;

    // Update status
    const updateSql = "UPDATE orders SET status = ?, updated_at = NOW() WHERE id = ?";
    const result = await query(updateSql, [status, orderId]);

    if (result.affectedRows === 0) {
      return res.status(400).json({
        success: false,
        error: "Failed to update order status",
      });
    }

    // Get updated order
    const [updatedOrder] = await query(
      "SELECT order_tracking_id FROM orders WHERE id = ?",
      [orderId]
    );

    res.json({
      success: true,
      message: "Order status updated",
      data: {
        orderId: orderId,
        orderTrackingId: updatedOrder.order_tracking_id,
        status: status,
      },
    });
  } catch (error) {
    console.error("Error updating order status:", error);
    res.status(500).json({
      success: false,
      error: "Failed to update order status",
      message: error.message,
    });
  }
});

export default router;
