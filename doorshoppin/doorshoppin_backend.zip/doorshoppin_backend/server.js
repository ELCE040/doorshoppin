import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import { connectToDatabase } from "./config/database.js";

// Import routes
import authRoutes from "./routes/auth.routes.js";
import productsRoutes from "./routes/products.routes.js";
import ordersRoutes from "./routes/orders.routes.js";

// Load .env
dotenv.config();

const app = express();
const PORT = process.env.PORT || 3001;
const HOST = "0.0.0.0";

// CORS middleware
app.use(cors({
  origin: process.env.CORS_ORIGIN || "*",
  methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
  allowedHeaders: ["Content-Type", "Authorization"],
  credentials: true
}));

// Handle OPTIONS preflight requests
app.options('*', (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', process.env.CORS_ORIGIN || '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.status(204).end();
});

// Body parsing middleware
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ limit: "10mb", extended: true }));

// Request logging middleware
app.use((req, res, next) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.path}`);
  next();
});

// Ensure all API responses are JSON
app.use((req, res, next) => {
  if (req.path.startsWith('/api') || req.path === '/health' || req.path === '/') {
    res.setHeader('Content-Type', 'application/json');
  }
  next();
});

// Error handlers
process.on('unhandledRejection', (reason, promise) => {
  console.error('❌ Unhandled Rejection at:', promise, 'reason:', reason);
});

process.on('uncaughtException', (error) => {
  console.error('❌ Uncaught Exception:', error);
});

// Favicon handler
app.get("/favicon.ico", (req, res) => {
  res.status(204).end();
});

// Root route
app.get("/", (req, res) => {
  res.setHeader('Content-Type', 'application/json');
  res.status(200).json({
    message: "Doorshoppin API",
    version: "1.0.0",
    endpoints: {
      health: "/health",
      auth: "/api/auth",
      products: "/api/products",
      orders: "/api/orders"
    }
  });
});

// Health check
app.get("/health", (req, res) => {
  res.setHeader('Content-Type', 'application/json');
  res.status(200).json({
    status: "OK",
    message: "Doorshoppin API is running",
    timestamp: new Date().toISOString()
  });
});

// API Routes
app.use("/api/auth", authRoutes);
app.use("/api/products", productsRoutes);
app.use("/api/orders", ordersRoutes);

// 404 fallback
app.use((req, res) => {
  console.log(`❌ 404 - Route not found: ${req.method} ${req.path}`);
  res.setHeader('Content-Type', 'application/json');
  res.status(404).json({
    error: "Route not found",
    path: req.path,
    method: req.method,
    availableEndpoints: {
      root: "GET /",
      health: "GET /health",
      auth: "/api/auth",
      products: "/api/products",
      orders: "/api/orders"
    }
  });
});

// Error handler
app.use((err, req, res, next) => {
  console.error('Error:', err);
  res.setHeader('Content-Type', 'application/json');
  res.status(err.status || 500).json({ 
    success: false, 
    error: 'Internal Server Error',
    message: err.message || 'Internal server error',
    ...(process.env.NODE_ENV === "development" && { stack: err.stack })
  });
});

// Start server
async function startServer() {
  try {
    console.log("🔄 Connecting to database...");
    await connectToDatabase();
    console.log("✅ Database connection established successfully");
  } catch (error) {
    console.error("⚠️  Database connection failed, but server will start anyway");
    console.error("⚠️  API endpoints will attempt to connect on each request");
    console.error("⚠️  Error:", error.message);
  }

  // Start server
  app.listen(PORT, HOST, () => {
    console.log("\n🚀 Doorshoppin Backend Server running");
    console.log(`🌍 Host: ${HOST}`);
    console.log(`🔌 Port: ${PORT}`);
    console.log("\n📘 Available Endpoints:");
    console.log("  GET  /");
    console.log("  GET  /health");
    console.log("  POST /api/auth/register");
    console.log("  POST /api/auth/login");
    console.log("  GET  /api/products");
    console.log("  GET  /api/products/:id");
    console.log("  POST /api/orders");
    console.log("  GET  /api/orders/my-orders");
    console.log("  GET  /api/orders/track/:orderId");
  });
}

startServer();
